<?php
    if(isset($_SERVER['HTTP_X_REQUESTED_WITH'])){
        echo "came from ajax";
    }else{
        include("includes/header.php");
        include("includes/footer.php");
    }
?>