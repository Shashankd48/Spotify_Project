<?php
    class Song{
        private $con;
        private $id;
        private $mysqliData;
        private $title;
        private $artistId = array();
        private $albumId;
        private $genre;
        private $duration;
        private $path;

        public function __construct($con, $id){
            $this->con = $con;
            $this->id = $id;

            // fetching albums info
            $query = mysqli_query($this->con,"select * from songs where id = '$this->id'");
            $this->mysqliData = mysqli_fetch_array($query);
            $this->title = $this->mysqliData['title'];
            $this->albumId = $this->mysqliData['album'];
            $this->genre = $this->mysqliData['genre'];
            $this->duration = $this->mysqliData['duration'];
            $this->path = $this->mysqliData['path'];
            for($i=0; $i<5; $i++){
                $this->artistId[$i] = $this->mysqliData['artist'.strval($i+1)];
            }
        }
        // getId of the ALbum with id
        public function getId(){
            return $this->id;
        }
        
        public function getTitle(){
            return $this->title;
        }

        // returning Album object
        public function getAlbumId(){
            return new Album($this->con,$this->albumId);
        }
        public function getGenre(){
            return $this->genre;
        }
        public function getDuration(){
            return $this->duration;
        }
        public function getPath(){
            return $this->path;
        }
        // returning array of object for artists
        public function getArtists(){
            $artistObj = array();
            for($i=0; $i<5; $i++){
                $artistObj[$i] = new Artist($this->con,$this->artistId[$i]);
            }
            return $artistObj;
        }

        //returning mysqliData object
        public function getMysqliData(){
            return $this->mysqliData;
        } 
    }
?>