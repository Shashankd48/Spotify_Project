<?php
    // temp playlist of 10 random songs
    $songQuery = mysqli_query($con,"select id from songs order by rand() limit 10");
    $resultArray = array();
    while($row = mysqli_fetch_array($songQuery)){
        array_push($resultArray,$row['id']);
    }

    // json array :-php array to json array so that is can be asign to javaScript array
    $jsonArray = json_encode($resultArray);
?>
<script>
    $(document).ready(function(){
        var newPlayList = <?php echo $jsonArray;?>;
        audioElement = new Audio();
        setTrack(newPlayList[0], newPlayList, false);
        updateVolumeProgressBar(audioElement.audio);

        $("#nowPlayingBarContainer").on("mousedown touchstart mousemove touchmove",function(e){
            e.preventDefault();
        });
        // dragging palybar by clicking
        $(".playbackBar .progressBar").mousedown(function(){
            mouseDown = true;
        });

        $(".playbackBar .progressBar").mousemove(function(e){
            if(mouseDown){
                // set time fo song depending on position of mouse
                timeFromOffset(e,this);
            }
        });

        $(".playbackBar .progressBar").mouseup(function(e){
            timeFromOffset(e,this);
        });

        // Volume controlbar
        $(".volumeBar .progressBar").mousedown(function(){
            mouseDown = true;
        });
        $(".volumeBar .progressBar").mousemove(function(e){
            if(mouseDown){
                var percentage = e.offsetX / $(this).width();
                if(percentage >= 0 && percentage <= 1){
                    audioElement.audio.volume = percentage;
                }
            }
        });
        $(".volumeBar .progressBar").mouseup(function(e){
            var percentage = e.offsetX / $(this).width();
                if(percentage >= 0 && percentage <= 1){
                    audioElement.audio.volume = percentage;
                }
        });

        $(document).mouseup(function(){
            mouseDown = false;
        });
    });

    function timeFromOffset(mouse, progressBar){
        // $(progressBar): creates a object of html element in Jquery
        // width() is the actual width of that html element
        var percentage = mouse.offsetX / $(progressBar).width() * 100;
        var seconds = audioElement.audio.duration *  (percentage / 100);
        audioElement.setTime(seconds);
    }
    // next song function
    function nextSong(){
        if(repeat){
            audioElement.setTime(0);
            playSong();
            return;
        }
        if(currentIndex == currentPlayList.length - 1){
            currentIndex = 0;
        }else{
            currentIndex++;
        }
        var trackToPlay = shuffle ? shufflePlayList[currentIndex] : currentPlayList[currentIndex];
        setTrack(trackToPlay,currentPlayList,true);
    }
    // previouse Song function
    function previousSong(){
        if(audioElement.audio.currentTime >= 3 || currentIndex == 0){
            audioElement.setTime(0);
        }else{
            currentIndex--;
            setTrack(currentPlayList[currentIndex],currentPlayList,true);
        }
    }
    // Reapeat song function
    function setRepeat(){
        repeat = !repeat;
        var imageName = repeat ? "repeat-active.png" : "repeat.png";
        $(".controlButton.repeat img").attr("src","assets/images/icons/" + imageName);
    }
    // Mute audio function
    function setMute(){
        audioElement.audio.muted = !audioElement.audio.muted;
        var imageName = audioElement.audio.muted ? "volume-mute.png" : "volume.png";
        $(".controlButton.volume img").attr("src","assets/images/icons/" + imageName);
    }
    // Suffle audio function
    function setShuffle(){
        shuffle = !shuffle;
        var imageName = shuffle ? "shuffle-active.png" : "shuffle.png";
        $(".controlButton.shuffle img").attr("src","assets/images/icons/" + imageName);
        if(shuffle){
            // randomize playlist
            shuffleArray(shufflePlayList);
            currentIndex = shufflePlayList.indexOf(audioElement.currentlyPlaying.id);
        }else{
            // shuffle off go back to regular playlist
            currentIndex = currentPlayList.indexOf(audioElement.currentlyPlaying.id);
        }
    }
    // for palylist shuffle
    function shuffleArray(a) {
        var j, x, i;
        for (i = a.length - 1; i > 0; i--) {
            j = Math.floor(Math.random() * (i + 1));
            x = a[i];
            a[i] = a[j];
            a[j] = x;
        }
        return a;
    }
    // setting mussic track to the audio and palylist
    function setTrack(trackId, newPlayList, play){
        if(newPlayList != currentPlayList){
            currentPlayList = newPlayList;
            shufflePlayList = currentPlayList.slice();
            shuffleArray(shufflePlayList);
            // delete them
            console.log("\n\tcurrent PlayList:\n",currentPlayList);
            console.log("\n\tShuffled PlayList:\n",shufflePlayList);
        }
        if(shuffle){
            currentIndex = shufflePlayList.indexOf(trackId);
        }else{
            currentIndex = currentPlayList.indexOf(trackId);
        }
        pauseSong();
        // making Ajax call to retrive songs php-->javascript
        $.post("includes/handlers/ajax/getSongJson.php",{songId: trackId},function(data){
            // json array to js object conversion
            var track = JSON.parse(data)

            // set song title on playbar
            $(".trackName span").text(track.title);

            // fetching artist name with id: looping for multiple artist 
            // And display them into the [.artistName span #id] element
            if(track[2]!=null){
                $.post("includes/handlers/ajax/getArtistJson.php",{artistId: track[2]},function(data){
                    // json array to js object conversion
                    var artist = JSON.parse(data);
                    $(".artistName #1").text(artist.name);
                });
            }
            if(track.artist2!=null){
                $.post("includes/handlers/ajax/getArtistJson.php",{artistId: track.artist2},function(data){
                    // json array to js object conversion
                    var artist = JSON.parse(data);
                    $(".artistName #2").text(","+artist.name);
                });
            }
            if(track.artist3!=null){
                $.post("includes/handlers/ajax/getArtistJson.php",{artistId: track.artist3},function(data){
                    // json array to js object conversion
                    var artist = JSON.parse(data);
                    $(".artistName #3").text(","+artist.name);
                });
            }
            if(track.artist4!=null){
                $.post("includes/handlers/ajax/getArtistJson.php",{artistId: track.artist4},function(data){
                    // json array to js object conversion
                    var artist = JSON.parse(data);
                    $(".artistName #4").text(","+artist.name);
                });
            }
            if(track.artist5!=null){
                $.post("includes/handlers/ajax/getArtistJson.php",{artistId: track.artist5},function(data){
                    // json array to js object conversion
                    var artist = JSON.parse(data);
                    $(".artistName #5").text(","+artist.name);
                });
            }
            // Artists name done here

            // fetching song Artwork
            $.post("includes/handlers/ajax/getAlbumJson.php",{albumSongArtId: track.id},function(data){
                    // json array to js object conversion
                    var songArtwork = JSON.parse(data);
                    console.log(songArtwork);
                    $(".albumLink img").attr("src",songArtwork.path);
                });
                // delete it
                console.log(track);
            // save them
            audioElement.setTrack(track);
            // delete this
            playSong();
        });

        if(play){
            audioElement.play();
        }  
    }
    // play, pause function for playbar buttons
    function playSong(){
        // updating song plays count if it start from zero
        if(audioElement.audio.currentTime == 0){
            $.post("includes/handlers/ajax/updatePlays.php",{ songId: audioElement.currentlyPlaying.id});
        }
        // hide buttons: show one at a time paly or pause
        $(".controlButton.play").hide();
        $(".controlButton.pause").show();
        audioElement.play();
    }
    function pauseSong(){
        $(".controlButton.pause").hide();
        $(".controlButton.play").show();
        audioElement.pause();
    }
</script>
<div id="nowPlayingBarContainer">
    <div id="nowPlayingBar">

        <!-- current playing music -->
        <div id="nowPlayingLeft">
            <div class="content">

                <!--  Display album Artwork -->
                <div class="albumLink">
                    <img src="assets/images/songImg/logo.jpg" alt="" class="albumArtwork">
                </div>

                <!-- Display Song Informartion -->
                <div class="trackInfo">

                    <!-- Song Title and song page link-->
                    <div class="trackName">
                        <span></span>
                    </div>

                    <!-- Artists and there page link -->
                    <div class="artistName">
                        <span>
                            <span id="1">Unknown</span>
                            <span id="2"></span>
                            <span id="3"></span>
                            <span id="4"></span>
                            <span id="5"></span>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- music controls -->
        <div id="nowPlayingCenter">
            <div class="content playerControls">
                <div class="buttons">
                    <button class="controlButton shuffle" title="Enable Shuffle" onclick="setShuffle()">
                        <img src="assets/images/icons/shuffle.png" alt="Shuffle">
                    </button>

                    <button class="controlButton previous" title="Previous" onclick="previousSong()">
                        <img src="assets/images/icons/previous.png" alt="Previous">
                    </button>

                    <button class="controlButton play" title="Play" onclick="playSong()">
                        <img src="assets/images/icons/play.png" alt="Play">
                    </button>

                    <button class="controlButton pause" title="Pause" style="display:none;"  onclick="pauseSong()">
                        <img src="assets/images/icons/pause.png" alt="Pause">
                    </button>

                    <button class="controlButton next" title="Next" onclick="nextSong()">
                        <img src="assets/images/icons/next.png" alt="Next">
                    </button>

                    <button class="controlButton repeat" title="Enable Repeat" onclick="setRepeat()">
                        <img src="assets/images/icons/repeat.png" alt="Repeat">
                    </button>
                </div>

                <!-- Progress bar -->
                <div class="playbackBar">
                    <span class="progressTime current">
                        0:00
                    </span>

                    <div class="progressBar">
                        <div class="progressBarBg">
                            <div class="progress"></div>
                        </div>
                    </div>

                    <span class="progressTime remaining">
                        0:00
                    </span>
                </div>

            </div>
        </div>

        <!-- voice control -->
        <div id="nowPlayingRight">
            <div class="volumeBar">
                <button class="controlButton volume" title="volume" onclick="setMute()">
                    <img src="assets/images/icons/volume.png" alt="volume">
                </button>
                <div class="progressBar volume">
                    <div class="progressBarBg">
                        <div class="progress"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>