<?php include("includes/header.php");

    // checking album id and if not exist then redirect to index.php
    if(isset($_GET['id'])){
        $albumId = $_GET['id'];
    }else{
        header("Location:index.php");
    }
    // getting album info from albums table
    $album = new Album($con,$albumId);

    // getting artist info from artist table
    $artist = $album->getArtist();
?>
    <!-- Album header -->
    <div class="entityInfo">
        <div class="leftSection">
            <img src="<?php echo $album->getArtworkPath();?>" alt="<?php echo $album->getTitle()?>">
        </div>
        <div class="rightSection">
            <h3><?php echo $album->getTitle();?></h3>
            <span class="artistName">By <?php echo $artist->getName();?></span>
            <p id="songCount"><?php echo $album->getNumberOfSongs();?> SONGS</p>
        </div>
    </div>

    <!-- Songs -->
    <div class="trackListContainer">
        <ul class="trackList">
            <?php   
                $songIdArray = $album->getSongIds();
                $allArtists = array();
                $artistsName = '';
                // trackCount for row
                $i = 1;
                foreach($songIdArray as $songId){

                    // song details from song table
                    $albumSong = new Song($con,$songId);

                    // one song have multiple artists fetching them and concatinating them
                    $allArtists = $albumSong->getArtists();
                    for($j=0; $j<5; $j++){
                        if($allArtists[$j]->getName()!=null){
                            if($j>0){
                                $artistsName = $artistsName.", ";
                            }
                            $artistsName = $artistsName.$allArtists[$j]->getName();
                        }else{
                            break;
                        }
                    }

                    // display song's :- Title, artists, number, playbutton
                    echo "<li class='trackListRow'>
                            <div class='trackCount'>
                                <img class='play' src='assets/images/icons/play-white.png' onclick='setTrack(\"". $albumSong->getId()."\", tempPlayList, true)'>
                                <span class='trackNumber'>$i</span>
                            </div>

                            <div class='trackInfo'>
                                <span class='trackName'>".$albumSong->getTitle()."</span>
                                <span class='artistName'>".$artistsName."</span>
                            </div>

                            <div class='trackOptions'>
                                <img class='optionsButton' src='assets/images/icons/more.png'>
                            </div>

                            <div class='trackDuration'>
                                <span class='duration'>".$albumSong->getDuration()."</span>
                            </div>
                        </li>";
                    $i++;
                    $artistsName = '';
                }
            ?>
            <!-- Temp Playlist for the album opened and if clicled play create new palylist -->
            <script>
                var tempSongIds = '<?php echo json_encode($songIdArray);?>';
                tempPlayList = JSON.parse(tempSongIds);
                // delete this
                console.log("\n\tTemp PlayLIst\n",temPlayList);
            </script>
        </ul>
    </div>
<?php include("includes/footer.php");?>