var currentPlayList = [];
var shufflePlayList = [];
var temPlayList = [];
var audioElement;
var mouseDown = false;
var currentIndex = 0;
var repeat = false;
var shuffle = false;
var userLoggedIn;

// remove the comment below
// function openPage(url){
//     if(url.indexOf("?") == -1){
//         url = url + "?";
//     }
//     var encodeUrl  = encodeURI(url + "&userLoggedIn=" + userLoggedIn);
//     $("#mainContent").load(encodeUrl);
// }
function formateTime(seconds){
    var time = Math.round(seconds);
    var minutes = Math.floor(time / 60);
    var seconds = time - (minutes * 60);
    var extraZero = (seconds < 10)? "0" : "";
    return minutes + ":" + extraZero + seconds;
}

// update progress bar
function updateTimeProgressBar(audio){
    $(".progressTime.current").text(formateTime(audio.currentTime));
    $(".progressTime.remaining").text(formateTime(audio.duration - audio.currentTime));

    // increaseing progress bar
    var progress = (audio.currentTime / audio.duration) * 100;
    // space between '.playbackBar' and '.progress' because they are two different div classes
    $(".playbackBar .progress").css("width", progress + "%");
}

//update valume bar 
function updateVolumeProgressBar(audio){
    var volume = audio.volume * 100;
    $(".volumeBar .progress").css("width", volume + "%");
}

function Audio(){
    this.currentlyPlaying;
    this.audio = document.createElement('audio');
    
    // After song ends do this
    this.audio.addEventListener("ended",function(){
        nextSong();
    });
    // Showing song remaining duration 
    this.audio.addEventListener("canplay",function(){
        // 'this' refers to the object that event was called on
        var duration = formateTime(this.duration);
        $(".progressTime.remaining").text(duration);
    });

    // calling Update progress bar
    this.audio.addEventListener("timeupdate",function(){
        if(this.duration){
            // 'this' is the audio object here
            updateTimeProgressBar(this);
        }
    });

    // calling update volume bar
    this.audio.addEventListener("volumechange",function(){
        updateVolumeProgressBar(this);
    });

    // track function
    this.setTrack = function(track){
        this.currentlyPlaying = track;
        this.audio.src = track.path;
    }
    this.play = function(){
        this.audio.play();
    }
    this.pause = function(){
        this.audio.pause();
    }
    this.setTime = function(seconds){
        this.audio.currentTime = seconds;
    }
}