<?php 
    include("includes/header.php");
    // include("includes/includedFiles.php");
?>
    <h3 class="pageHeadingBig">You Might Also Like</h3>

    <div class="gridViewContainer">
        <?php
            $albumQuery = mysqli_query($con,"select * from albums order by rand() limit 10");
            $artistName = "select name from artists where id = ";
            while($row = mysqli_fetch_array($albumQuery)){

                // geting artist name for albums from the artist table
                $artistsQuery = mysqli_query($con,$artistName.$row['artist']);
                $arName = mysqli_fetch_array($artistsQuery);
                echo "<div class='gridViewItem'>
                        <a href='album.php?id=".$row['id']."'>
                        <img src='". $row['artworkpath']. "'>
                        <div class='gridViewInfo'>
                            <span>" . $row['title'] . "</span>
                            <p>". $arName['name']."</p>
                        </div>
                        </a>
                     </div>";
            }
        ?>
    </div>
<?php include("includes/footer.php");?>                    