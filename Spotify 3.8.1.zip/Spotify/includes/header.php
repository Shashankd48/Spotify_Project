<?php
    include('includes/config.php');
    include('includes/classes/Artist.php');
    include('includes/classes/Album.php');
    include('includes/classes/Song.php');
    if(isset($_SESSION['userLoggedIn'])){
        $userLoggedIn = $_SESSION['userLoggedIn'];
    }else{
        header('location:register.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">

    <!-- my style css -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- my javascript -->
    <script src="assets/js/script.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <!-- fivicon -->
    <link rel = "icon" type = "image/jpg" href = "assets/images/icons/Spotify_Green.png">

    <!-- JQuery link -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->
    <!-- google font -->
    <link href="https://fonts.googleapis.com/css?family=Nunito|PT+Sans&display=swap" rel="stylesheet"> 

    <title>Spotify - Home</title>
</head>
<body>
    <!-- copy username to the javascript variable -->
    <?php
         if($userLoggedIn){
            echo "<script>userLoggedIn = '$userLoggedIn';</script>";
        }
    ?>
    <div id="mainContainer">

        <!-- main content -->
        <div id="topContainer">

            <!-- navigation bar -->
            <?php include("includes/navBarContainer.php");?>

            <!-- Music container -->
            <div id="mainViewContainer">
                <div id="mainContent">