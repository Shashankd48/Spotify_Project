<?php
    include("../../config.php");
    if(isset($_POST['albumSongArtId'])){
        $albumSongArtId = $_POST['albumSongArtId'];
        $query = mysqli_query($con,"select path from songartwork where id = '$albumSongArtId'");
        $resultArray = mysqli_fetch_array($query);
        echo json_encode($resultArray);
    }
?>