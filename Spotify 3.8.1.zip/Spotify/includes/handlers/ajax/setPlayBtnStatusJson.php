<?php
    include("../../config.php");
    if(isset($_POST['currentPageName'])){
        $currentPageName = $_POST['currentPageName'];
        $query = mysqli_query($con,"update pageplaybuttonstatus set playbuttonstatus = not playbuttonstatus where pagename = '$currentPageName'");
    }
?>