<?php
    include("../../config.php");
    if(isset($_POST['currentPageName'])){
        $currentPageName = $_POST['currentPageName'];
        $query = mysqli_query($con,"select * from pageplaybuttonstatus where pagename = '$currentPageName'");
        $resultArray = mysqli_fetch_array($query);
        echo json_encode($resultArray);
    }
?>