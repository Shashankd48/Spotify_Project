<?php
    class Account{
        private $errorArray;
        private $con;
        public function __construct($con){
            $this->errorArray = array();
            $this->con = $con;
        }
        public function clearError(){
            $this->errorArray = null;
        }

        //for sign up page
        public function register($un,$fn,$ln,$em,$em2,$pw,$pw2){
            // validating the data
            $this->validateUsername($un);
            $this->validatefirstname($fn);
            $this->validateLastname($ln);
            $this->validateEmails($em,$em2);
            $this->validatePassword($pw,$pw2);
            if(empty($this->errorArray)){
                // insert into db
                return $this->insertUserDetails($un,$fn,$ln,$em,$pw);
            }
            else{
                // something went wrong!!!
                return false;
            }
        }

        //for login page
        public function login($un,$pw){
            $pw = md5($pw);
            $query = mysqli_query($this->con,"select *from users where username = '$un' AND password = '$pw'");
            if(mysqli_num_rows($query)==1){
                return true;
            }else{
                array_push($this->errorArray,Constrants::$loginFailed);
                return false;
            }
        } 

        //inseting data to the database
        private function insertUserDetails($un,$fn,$ln,$em,$pw){
            $encryptedPw = md5($pw);    //md5() is password incryption method
            $profilePic = "assets/images/profile-pics/Kacee-Piper.jpg";
            $date = date("Y-m-d");
            $result = mysqli_query($this->con,"insert into users(id,username,firstname,lastname,email,password,signupdate,profilepic) values('','$un','$fn','$ln','$em','$encryptedPw','$date','$profilePic')");
            return $result;
        }

        //function to show error message in form validation 
        public function getError($error){
            // in_aaray(checkThis , intoThis)
            if(!in_array($error,$this->errorArray)){
                $error = "";
            }
            return "<span class='errorMessage'>$error</span>";
        }

        //private functions for data validation
        private function validateUsername($un){
            if(strlen($un)>25 || strlen($un)<5){
                array_push($this->errorArray,Constrants::$usernameLength);
                return;
            }
            $checkUsernameQuery = mysqli_query($this->con,"select username from users where username = '$un'");
            if(mysqli_num_rows($checkUsernameQuery)!=0){
                array_push($this->errorArray,Constrants::$userNameTaken);
            }
        }
        private function validateFirstname($fn){
            if(strlen($fn)>50 || strlen($fn)<2){
                array_push($this->errorArray,Constrants::$fnLength);
                return;
            }
        }
        private function validateLastname($ln){
            if(strlen($ln)>30 || strlen($ln)<2){
                array_push($this->errorArray,Constrants::$lnLength);
                return;
            }
        }
        private function validateEmails($em,$em2){
            if($em!=$em2){
                array_push($this->errorArray,Constrants::$emailNotMatch);
                return;
            }
            if(!filter_var($em,FILTER_VALIDATE_EMAIL)){
                array_push($this->errorArray,Constrants::$emailInvalid);
                return;
            }
            $checkEmailQuery = mysqli_query($this->con,"select email from users where email = '$em'");
            if(mysqli_num_rows($checkEmailQuery)!=0){
                array_push($this->errorArray,Constrants::$emailTaken);
            }
        }
        private function validatePassword($pw,$pw2){
            if($pw!=$pw2){
                array_push($this->errorArray,Constrants::$pwDoNotMatch);
                return;
            }
            // preg_metch("pattern",data,) is used to find pattern in string
            if(preg_match('/[^A-Za-z0-9]/',$pw,)){
                array_push($this->errorArray,Constrants::$pwNotAlphanumeric);
                return;
            }
            if(strlen($pw)>25 || strlen($pw)<6){
                array_push($this->errorArray,Constrants::$pwLength);
                return;
            }
        }
    }
?>