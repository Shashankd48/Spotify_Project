<?php
    class Constrants{
        public static $pwDoNotMatch = "Your password don't match";
        public static $pwNotAlphanumeric = "Your password can only contain numbers and letters";
        public static $pwLength = "Your password must be between 6 and 25 characters";

        public static $emailNotMatch = "Your email don't match";
        public static $emailInvalid = "Email is invalid";

        public static $lnLength = "Your last name must be between 2 and 30 characters";
        public static $fnLength = "Your first name must be between 2 and 50 characters";

        public static $usernameLength = "Your username must be between 5 and 25 characters";

        public static $userNameTaken = "This username already exists";
        public static $emailTaken = "This email is already in use";

        // login errors
        public static $loginFailed = "Your username or password was incorrect";
    }
?>