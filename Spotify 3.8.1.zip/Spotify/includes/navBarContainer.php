<div id="navBarContainer">
    <nav class="navBar">
        <!-- Spotify logo -->
        <span roll='link' onclick='openPage("home.php")' class='logo'>
            <img src="assets/images/logo/Spotify_Logo_White.png" alt="spotify">
        </span>
        
        <!-- navigation Items -->
        <!-- other items -->
        <div class="group">
            <div class="navItem" roll="link" tabindex="0" onclick="openPage('home.php')" >
                <span class="navItemLink">
                <svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M 256.274 60.84 L 84.324 166.237 L 84.324 443.063 L 193.27 443.063 L 193.27 293.73 L 320.228 293.73 L 320.228 443.063 L 428.222 443.063 L 428.222 165.476 L 256.274 60.84 Z M 256.274 35.95 L 448.452 149.145 L 448.452 464.395 L 300 464.395 L 300 315.062 L 213.499 315.062 L 213.499 464.395 L 64.095 464.395 L 64.095 150.161 L 256.274 35.95 Z" ></path></svg>         
                </span>
                <span class="navLinkText">Home</span>
            </div>

            <div class="navItem" roll="link" tabindex="0" onclick="openPage('search.php')">
                <span class="navItemLink search">
                    <svg viewBox="0 0 512 512" width="24" height="24" xmlns="http://www.w3.org/2000/svg"><path d="M349.714 347.937l93.714 109.969-16.254 13.969-93.969-109.969q-48.508 36.825-109.207 36.825-36.826 0-70.476-14.349t-57.905-38.603-38.603-57.905-14.349-70.476 14.349-70.476 38.603-57.905 57.905-38.603 70.476-14.349 70.476 14.349 57.905 38.603 38.603 57.905 14.349 70.476q0 37.841-14.73 71.619t-40.889 58.921zM224 377.397q43.428 0 80.254-21.461t58.286-58.286 21.461-80.254-21.461-80.254-58.286-58.285-80.254-21.46-80.254 21.46-58.285 58.285-21.46 80.254 21.46 80.254 58.285 58.286 80.254 21.461z" fill-rule="evenodd"></path></svg>       
                </span>
                <span class="navLinkText">Search</span>
            </div>

            <div class="navItem" roll="link" tabindex="0" onclick="openPage('yourMusic.php')"> 
                <span class="navItemLink">
                <svg viewBox="0 0 512 512" width="24" height="24" xmlns="http://www.w3.org/2000/svg"><path d="M291.301 81.778l166.349 373.587-19.301 8.635-166.349-373.587zM64 463.746v-384h21.334v384h-21.334zM192 463.746v-384h21.334v384h-21.334z"</path></svg>
                </span>
                <span class="navLinkText">Your Library</span>
            </div>
            <div class="navItem" roll="link" tabindex="0" onclick="openPage('profile.php')"> 
                <span class="navItemLink">
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 483.5 483.5" style="enable-background:new 0 0 483.5 483.5;" xml:space="preserve">
                    <g>
                        <g>
                            <path d="M430.75,471.2v-67.8c0-83.9-55-155.2-130.7-179.8c36.4-20.5,61.1-59.5,61.1-104.2c0-65.8-53.6-119.4-119.4-119.4
                                s-119.4,53.6-119.4,119.4c0,44.7,24.7,83.7,61.1,104.2c-75.8,24.6-130.7,95.9-130.7,179.8v67.8c0,6.8,5.5,12.3,12.3,12.3h353.6
                                C425.25,483.4,430.75,478,430.75,471.2z M146.75,119.4c0-52.3,42.6-94.9,94.9-94.9s94.9,42.6,94.9,94.9s-42.6,94.9-94.9,94.9
                                S146.75,171.7,146.75,119.4z M406.25,458.9H77.05v-55.6c0-90.7,73.8-164.6,164.6-164.6s164.6,73.8,164.6,164.6V458.9z"/>
                        </g>
                    </g>
                </svg>
                </span>
                <span class="navLinkText"><?php echo $userLoggedIn;?></span>
            </div>
            <div class="navItem logout">
                <a href="logout.php" class="navItemLink">
                <svg height="30pt" viewBox="1 0 511 512" width="30pt" xmlns="http://www.w3.org/2000/svg"><path d="m135.738281 361.070312c7.140625 8.425782 6.097657 21.046876-2.328125 28.1875-8.4375 7.148438-21.058594 6.085938-28.1875-2.328124l-100.007812-118c-6.378906-7.523438-6.191406-18.558594 0-25.859376l100.007812-118c7.140625-8.429687 19.761719-9.46875 28.1875-2.328124 8.425782 7.140624 9.46875 19.761718 2.328125 28.1875l-72.097656 85.070312h355.042969c11.046875 0 20.003906 8.953125 20.003906 20s-8.957031 20-20.003906 20h-355.042969zm356.761719-361.070312h-173.820312c-11.046876 0-20 8.953125-20 20s8.953124 20 20 20h153.816406v432h-153.816406c-11.046876 0-20 8.953125-20 20s8.953124 20 20 20h173.820312c11.042969 0 20-8.953125 20-20v-472c0-11.046875-8.957031-20-20-20zm0 0"/></svg>
                    Logout
                </a>
            </div>
        </div>
        <div class="group">
            <div id="playListSection">
            <span>PlayLists</span>
            </div>
            <div id="playList">
                <div class="navItem" roll="link" tabindex="0" onclick="openPage('search.php')">
                    <button class="playListSecBtn">
                        <span class="navItemLink createPlaylist">
                        <svg class="CreatePlaylistButton__svg" shape-rendering="crispEdges" viewBox="0 0 36 36"><path class="CreatePlaylistButton__svg-plus-path" d="m28 20h-8v8h-4v-8h-8v-4h8v-8h4v8h8v4z"></path></svg>
                    </span>
                    </button>
                    <span class="navLinkText">Create Playlist</span>
                </div>
                <div class="navItem" roll="link" tabindex="0" onclick="openPage('search.php')">
                    <button class="likedSongBtn spoticon-heart-active-16">
                        <span class="navItemLink likedSong">
                        <i class="fas fa-heart"></i>
                        </span>
                    </button>
                    <span class="navLinkText">Liked Songs</span>
                </div>
            </div>
        </div>
        <div class="topPlaylists">
            <div class="group">
                <div class="playListItem">
                    <span class="playListItem">Bollywood</span>
                </div>
                <div class="playListItem">
                    <span class="playListItem">God</span>
                </div>
                <div class="playListItem">
                    <span class="playListItem">English Songs New Release</span>
                </div>
                <div class="playListItem">
                    <span class="playListItem">New Panjabi Songs</span>
                </div>
                <div class="playListItem">
                    <span class="playListItem">Hollywoord</span>
                </div>
                <div class="playListItem">
                    <span class="playListItem">Rap Songs</span>
                </div>
                <div class="playListItem">
                    <span class="playListItem">Romantic Songs</span>
                </div>
            </div>
        </div>
    </nav>
</div>