<?php
    echo "<h2>Welcome XYZ</h2>";
?>