var currentPlayList = [];
var shufflePlayList = [];
var temPlayList = [];
var audioElement;
var mouseDown = false;
var currentIndex = 0;
var repeat = false;
var shuffle = false;
var userLoggedIn;

// for artist section play button
var artistPlay = true;
var firstTimeArtistPlay = 1;
var firtTimeAlbumPlay = 1;

// current Page url
var currentUrl;

// Page playButton Status
var pageName = null;
var artistPagePlayBtn = null;
var albumPagePlayBtn = null;
var songPagePlayBtn = null;


function setCurrentURL(){
    currentUrl = window.location.href;
    console.log(currentUrl);
    currentUrl = currentUrl.replace("http://localhost/BasicPhp/Spotify/","");
    console.log(currentUrl);
}
setCurrentURL();

window.addEventListener("popstate", function() {
    var url = location.href;
    openPagePushState(url);
    setCurrentURL();
});
function openPagePushState(url) {
    // if(timer !== null) {
    //   clearTimeout(timer);
    // }
    if(url.indexOf("?") == -1) {
        url = url + "?";
    }
    // var encodedUrl = encodeURI(url);
    var encodedUrl  = encodeURI(url + "&userLoggedIn=" + userLoggedIn);
    $("#mainContent").load(encodedUrl);
    $("body").scrollTop(0);
}
function openPage(url) {
    if(currentUrl != url){
        currentUrl = url;

        // delete this
        // console.log("URL ",url);
        // console.log("Artist Search: ",url.search("artist"));
        // console.log("Album Search: ",url.search("album"));
        // console.log("Song Search: ",url.search("song"));

        if(url.search("artist") != -1){
            pageName = "artist";
            console.log("pageName  = ",pageName);
        }else if(url.search("album") != -1){
            pageName = "album";
            console.log("pageName  = ",pageName);
        }else if(url.search("song") != -1){
            pageName = "song";
            console.log("pageName  = ",pageName);
        }
        getPlayBtnStatus();
        openPagePushState(url);
        history.pushState(null, null, url);
        firstTimeArtistPlay = 1;
    }
}


function formateTime(seconds){
    var time = Math.round(seconds);
    var minutes = Math.floor(time / 60);
    var seconds = time - (minutes * 60);
    var extraZero = (seconds < 10)? "0" : "";
    return minutes + ":" + extraZero + seconds;
}

// update progress bar
function updateTimeProgressBar(audio){
    $(".progressTime.current").text(formateTime(audio.currentTime));
    $(".progressTime.remaining").text(formateTime(audio.duration - audio.currentTime));

    // increaseing progress bar
    var progress = (audio.currentTime / audio.duration) * 100;
    // space between '.playbackBar' and '.progress' because they are two different div classes
    $(".playbackBar .progress").css("width", progress + "%");
}

//update valume bar 
function updateVolumeProgressBar(audio){
    var volume = audio.volume * 100;
    $(".volumeBar .progress").css("width", volume + "%");
}

function playToPauseText(){
    $(".headerButton button").text("PAUSE");
    $(".songPagePlayButton button").text("PAUSE");
    $(".albumPlayButton button").text("PAUSE");
}

function pauseToPlayText(){
    $(".headerButton button").text("PLAY");
    $(".songPagePlayButton button").text("PLAY");
    $(".albumPlayButton button").text("PLAY");
}

function Audio(){
    this.currentlyPlaying;
    this.audio = document.createElement('audio');
    
    // After song ends do this
    this.audio.addEventListener("ended",function(){
        nextSong();
    });
    // Showing song remaining duration 
    this.audio.addEventListener("canplay",function(){
        // 'this' refers to the object that event was called on
        var duration = formateTime(this.duration);
        $(".progressTime.remaining").text(duration);
    });

    // calling Update progress bar
    this.audio.addEventListener("timeupdate",function(){
        if(this.duration){
            // 'this' is the audio object here
            updateTimeProgressBar(this);
        }
    });

    // calling update volume bar
    this.audio.addEventListener("volumechange",function(){
        updateVolumeProgressBar(this);
    });

    // track function
    this.setTrack = function(track){
        this.currentlyPlaying = track;
        this.audio.src = track.path;
    }
    this.play = function(){
        this.audio.play();
        playToPauseText();
    }
    this.pause = function(){
        this.audio.pause();
        pauseToPlayText();
    }
    this.setTime = function(seconds){
        this.audio.currentTime = seconds;
    }
}

// get page Play button status function
function getPlayBtnStatus(){
    $.post("includes/handlers/ajax/getPlayBtnStatusJson.php",{currentPageName: pageName},function(data){
        // json array to js object conversion
        var aboutPage = JSON.parse(data);
        if(aboutPage.pagename == "artist"){
            artistPagePlayBtn = aboutPage.playbuttonstatus;
            console.log("Artist Play Button",artistPagePlayBtn);
        }else if(aboutPage.pagename == "album"){
            albumPagePlayBtn = aboutPage.playbuttonstatus;
            console.log("Album Play Button",albumPagePlayBtn);
        }else if(aboutPage.pagename == "song"){
            songPagePlayBtn = aboutPage.playbuttonstatus;
            console.log("Song Play Button",songPagePlayBtn);
        }
    });
}
function setPlayBtnStatus(){
    $.post("includes/handlers/ajax/setPlayBtnStatusJson.php",{currentPageName: pageName});
}