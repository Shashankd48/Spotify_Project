<?php 
    include("includes/includedFiles.php");
?>
<script>
    openPage("home.php");
</script>