<?php
    include('includes/config.php');
    if(isset($_SESSION['userLoggedIn'])){
        $userLoggedIn = $_SESSION['userLoggedIn'];
    }else{
        header('location:login.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <!-- fivicon -->
    <link rel = "icon" type = "image/jpg" href = "spotify.png">
    <title>Spotify</title>
</head>
<body>
    <div class="container">
    <h1><i class="fab fa-spotify"></i> Spotify</h1>
        <a href="login.php" class="btn btn-success btn-lg">Login</a>   
        <a href="register.php" class="btn btn-lg btn-dark">Signup</a>
        <br><br><a href="logout.php">logout</a>
        <br>
        <a href="termsAndConditions.html">Terms & Conditions.</a>
    </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>