<?php
    include("includes/includedFiles.php");
    include('includes/classes/Artwork.php');
    // checking album id and if not exist then redirect to index.php
    if(isset($_GET['id'])){
        $artistId = $_GET['id'];
    }else{
        header("Location:index.php");
    }
    $artist = new Artist($con,$artistId);
    $totalListener = 0;
?>
<div class="entityInfo borderBottom">
    <div class="centerSection">
        <div class="artistInfo">
            <h1 class="artistName"><?php echo $artist->getName();?></h1>
            <div class="headerButton">
                <button class="button" onclick="playFirstSong()"> 
                    PLAY
                </button>
            </div>
        </div>
    </div>
</div>

<!-- List top 20 song for that artist across all album -->
<h3 class="pageHeadingBig">Popular</h3>
<div class="trackListContainer borderBottom">
        <ul class="trackList">
            <?php   
                $songIdArray = $artist->getSongIds();
                $allArtists = array();
                $artistsName = '';
                // trackCount for row
                $i = 1;
                foreach($songIdArray as $songId){
                    if($i>20){
                        break;
                    }
                    // song details from song table
                    $albumSong = new Song($con,$songId);
                    $songArtwork = new Artwork($con,$songId);

                    // one song have multiple artists fetching them and concatinating them
                    $allArtists = $albumSong->getArtists();
                    for($j=0; $j<5; $j++){
                        if($allArtists[$j]->getName()!=null){
                            if($j>0){
                                $artistsName = $artistsName.", ";
                            }
                            $artistsName = $artistsName.$allArtists[$j]->getName();
                        }else{
                            break;
                        }
                    }

                    // display song's :- Title, artists, number, playbutton
                    echo "<div class='artistPagesTracks'>
                        <li class='trackListRow'>
                            <div class='trackCount'>
                                <img class='play' src='assets/images/icons/play-white.png' onclick='setTrack(\"". $albumSong->getId()."\", tempPlayList, true)'>
                                <span class='trackNumber'>$i</span>
                            </div>

                            <div class='songArtwork'>
                                <img src='".$songArtwork->getpath()."' alt='' width='57px' class='songImg'>
                            </div>

                            <div class='trackInfo'>
                                <span class='trackName'>".$albumSong->getTitle()."</span>
                            </div>

                            <div class='trackOptions'>
                                <img class='optionsButton' src='assets/images/icons/more.png'>
                            </div>

                            <div class='trackDuration'>
                                <span class='duration'>".$albumSong->getDuration()."</span>
                            </div>
                        </li>
                        </div>";
                    $i++;
                    $artistsName = '';
                }
            ?>
            <!-- Temp Playlist for the album opened and if clicled play create new palylist -->
            <script>
                var tempSongIds = '<?php echo json_encode($songIdArray);?>';
                tempPlayList = JSON.parse(tempSongIds);
                // delete this
                console.log("\n\tTemp PlayLIst\n",temPlayList);
            </script>
        </ul>
    </div>

    <!-- Album Section in Artits Page -->
    <h3 class="pageHeadingBig">Albums</h3>
    <div class="gridViewContainer">
        <?php
            $albumQuery = mysqli_query($con,"select * from albums where artist = '$artistId'");
            $artistName = "select name from artists where id = ";
            while($row = mysqli_fetch_array($albumQuery)){

                // geting artist name for albums from the artist table
                $artistsQuery = mysqli_query($con,$artistName.$row['artist']);
                $arName = mysqli_fetch_array($artistsQuery);
                echo "<div class='gridViewItem'>
                <span roll='link' tabindex='0' onclick='openPage(\"album.php?id=".$row['id']."\")'>
                        <img src='". $row['artworkpath']. "'>
                        <div class='gridViewInfo'>
                            <span>" . $row['title'] . "</span>
                            <p>". $arName['name']."</p>
                        </div>
                        </span>
                     </div>";
            }
        ?>
    </div>