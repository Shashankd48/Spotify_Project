<?php include("includes/includedFiles.php");;

    // checking album id and if not exist then redirect to index.php
    if(isset($_GET['id'])){
        $albumId = $_GET['id'];
    }else{
        header("Location:index.php");
    }
    // getting album info from albums table
    $album = new Album($con,$albumId);
    // getting artist info from artist table
    $artist = $album->getArtist();
?>
    <script>
        // var upperClassName;
        // function setUpperClass(classId){
        //     upperClassName = classId;
        // }
        function setAlbumPageLink(artistId,spanClass,upperClassName){
            var className = ".trackInfo."+upperClassName+" .artistName." + spanClass;
            console.log(className);
            $(className).attr("onclick","openPage('artist.php?id="+artistId+"')");
            firstTimeArtistPlay = 1;
        }
    </script>
    <!-- Album header -->
    <div class="entityInfo">
        <div class="leftSection">
            <img src="<?php echo $album->getArtworkPath();?>" alt="<?php echo $album->getTitle()?>">
        </div>
        <div class="rightSection">
            <h3><?php echo $album->getTitle();?></h3>
            <span class="artistName">By <?php echo $artist->getName();?></span>
            <p id="songCount"><?php echo $album->getNumberOfSongs();?> SONGS</p>
            <div class="albumPlayButton">
                <button class="button" onclick="albumPlayButton()"> 
                    PLAY
                </button>
            </div>
        </div>
    </div>

    <!-- Songs -->
    <div class="trackListContainer">
        <ul class="trackList">
            <?php   
                $songIdArray = $album->getSongIds();
                $allArtists = array();
                $artistsName = '';
                // trackCount for row
                $j = 1;
                foreach($songIdArray as $songId){

                    // song details from song table
                    $albumSong = new Song($con,$songId);

                    // one song have multiple artists fetching them and concatinating them
                    $allArtists = $albumSong->getArtists();

                    // display song's :- Title, artists, number, playbutton
                    echo "<li class='trackListRow'>
                            <div class='trackCount'>
                                <img class='play' src='assets/images/icons/play-white.png' onclick='setTrack(\"". $albumSong->getId()."\", tempPlayList, true)'>
                                <span class='trackNumber'>$j</span>
                            </div>

                            <div class='trackInfo $j'>
                                <span class='trackName'>".$albumSong->getTitle()."</span>
                                ";
                                // delete this
                                // echo "<script> setUpperClass('$j');</script>";
                                for($i=0; $i<5; $i++){
                                    $artistsName = $allArtists[$i]->getName();
                                    $artistId = $allArtists[$i]->getId();
                                    if($artistsName){
                                        if($i>0){
                                            echo "
                                            <span class='artistName'>,</span>";    
                                        }
                                        $page = "artist.php?id=5";
                                        echo "
                                            <span class='artistName $i'>".$artistsName."</span>";
                                            // setLink Function is in script.js that call
                                            echo "<script> setAlbumPageLink('$artistId','$i','$j');  </script>";
                                    }else{
                                        break;
                                    }
                                }
                            echo "
                            </div>

                            <div class='trackOptions'>
                                <img class='optionsButton' src='assets/images/icons/more.png'>
                            </div>

                            <div class='trackDuration'>
                                <span class='duration'>".$albumSong->getDuration()."</span>
                            </div>
                        </li>";
                    $j++;
                    $artistsName = '';
                }
            ?>
            <!-- Temp Playlist for the album opened and if clicled play create new palylist -->
            <script>
                var tempSongIds = '<?php echo json_encode($songIdArray);?>';
                tempPlayList = JSON.parse(tempSongIds);
                // delete this
                console.log("\n\tTemp PlayLIst\n",temPlayList);
            </script>
        </ul>
    </div>