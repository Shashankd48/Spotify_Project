<?php include("includes/includedFiles.php");;

    // checking album id and if not exist then redirect to index.php
    if(isset($_GET['id'])){
        $songId = $_GET['id'];
    }else{
        header("Location:index.php");
    }
    // getting album info from albums table
    $song = new Song($con,$songId);
    // $album = new Album($con,());
    $album = $song->getAlbumId();
    $artists = $song->getArtists();

    // getting artist info from artist table for Album
    $artist =  $album->getArtist()
?>
    <script>
        function setLink(artistId,spanClass){
            var className = ".artistName." + spanClass;
            $(className).attr("onclick","openPage('artist.php?id="+artistId+"')");
            firstTimeArtistPlay = 1;
        }
    </script>
    <!-- Album header -->
    <div class="entityInfo">
        <div class="leftSection">
            <img src="<?php echo $song->getSongArtworkPath();?>" alt="<?php echo $album->getTitle()?>">
        </div>
        <div class="rightSection">
            <h3><?php echo $song->getTitle();?></h3>

            <!-- Album Name -->
            <span class='artistName'><?php echo $album->getTitle();?></span>

            <p id="songCount">1 SONG</p>

            <div class="songPagePlayButton">
                <button class="button" onclick="albumPlayButton()"> 
                    PLAY
                </button>
            </div>

            <span class="copyWrites">℗ 2020 Spotify India Pvt. Ltd.</span>
        </div>
    </div>

    <!-- Songs -->
    <div class="trackListContainer">
        <ul class="trackList">
            <?php   
                    // display song's :- Title, artists, number, playbutton
                echo "<li class='trackListRow'>
                        <div class='trackCount'>
                            <img class='play' src='assets/images/icons/play-white.png' onclick='setTrack(\"". $song->getId()."\", tempPlayList, true)'>
                            <span class='trackNumber'>1</span>
                        </div>

                        <div class='trackInfo'>
                            <span class='trackName'>".$song->getTitle()."</span>
                            ";
                            for($i=0; $i<5; $i++){
                                $artistName = $artists[$i]->getName();
                                $artistId = $artists[$i]->getId();
                                if($artistName){
                                    if($i>0){
                                        echo "
                                        <span class='artistName'>,</span>";    
                                    }
                                    echo "
                                        <span roll='link' class='artistName $i'>".$artistName."</span>";
                                        // setLink Function is in script.js that call
                                        echo "<script> setLink('$artistId','$i');  </script>";
                                }else{
                                    break;
                                }
                            }
                echo "
                        </div>

                        <div class='trackOptions'>
                            <img class='optionsButton' src='assets/images/icons/more.png'>
                        </div>

                        <div class='trackDuration'>
                            <span class='duration'>".$song->getDuration()."</span>
                        </div>
                    </li>";
            ?>
            <!-- Temp Playlist for the album opened and if clicled play create new palylist -->
            <script>
                var tempSongIds = '<?php echo json_encode($song->getId());?>';
                tempPlayList = JSON.parse(tempSongIds);
                // delete this
                console.log("\n\tTemp PlayLIst\n",temPlayList);
             </script>
        </ul>
    </div>