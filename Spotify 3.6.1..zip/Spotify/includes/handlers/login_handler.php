<?php
    if(isset($_POST['Login'])){
        // echo "Clicked";
        $username = $_POST['username'];
        $password = $_POST['password'];
        $result = $account->login($username,$password);
        if($result){
            $_SESSION['userLoggedIn'] = $username;
            header('location:index.php');
        }
    }
?>