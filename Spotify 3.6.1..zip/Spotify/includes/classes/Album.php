<?php
    class Album{
        private $con;
        private $id;
        private $title;
        private $artistId;
        private $genre;
        private $artworkPath;

        public function __construct($con, $id){
            $this->con = $con;
            $this->id = $id;

            // fetching albums info
            $query = mysqli_query($this->con,"select * from albums where id = '$this->id'");
            $album = mysqli_fetch_array($query);

            $this->title = $album['title'];
            $this->artistId = $album['artist'];
            $this->genre = $album['genre'];
            $this->artworkPath = $album['artworkpath'];
        }
        // getTitle of the ALbum with id
        public function getTitle(){
            return $this->title;
        }
        // getting artist id here
        public function getArtist(){
            return new Artist($this->con, $this->artistId);
        }
        // getting album genre here
        public function getGenre(){
            return $this->genre;
        }
        // getting album artwork here
        public function getArtworkPath(){
            return $this->artworkPath;
        }
        public function getNumberOfSongs(){
            $query = mysqli_query($this->con,"select id from songs where album = '$this->id'");
            return mysqli_num_rows($query);
        }

        // Songs to the trackListContainer
        public function getSongIds(){
            $query = mysqli_query($this->con,"select id from songs where album = '$this->id' order by albumorder asc");
            $array = array();
            while($row = mysqli_fetch_array($query)){
                array_push($array, $row['id']);
            }
            return $array;
        }
    }
?>