<?php
    class Artwork{
        private $id;
        private $con;
        private $mysqliData;
        private $path;
        public function __construct($con, $id){
            $this->con = $con;
            $this->id = $id;
            $query = mysqli_query($this->con,"select * from songartwork where id = '$this->id'");
            $this->mysqliData = mysqli_fetch_array($query);
            $this->path = $this->mysqliData['path'];
        }
        public function getPath(){
            return $this->path;
        }
    }
?>