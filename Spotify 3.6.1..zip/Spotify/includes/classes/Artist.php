<?php
    class Artist{
        private $con;
        private $id;

        public function __construct($con, $id){
            $this->con = $con;
            $this->id = $id;
        }
        public function getName(){
            $artistsQuery = mysqli_query($this->con,"select name from artists where id = '$this->id'");
            $artist = mysqli_fetch_array($artistsQuery);
            return $artist['name'];
        }
        public function getId(){
            return $this->id;
        }
        // get song across all the album by artist
        public function getSongIds(){
            $query = mysqli_query($this->con,"select id from songs where artist1 = '$this->id' or artist2 = '$this->id' or artist3 = '$this->id' or artist4 = '$this->id' or artist5 = '$this->id' order by plays desc ");
            $array = array();
            while($row = mysqli_fetch_array($query)){
                array_push($array, $row['id']);
            }
            return $array;
        }
    }
?>