<?php
    include('includes/config.php');
    if(isset($_SESSION['userLoggedIn'])){
        $userLoggedIn = $_SESSION['userLoggedIn'];
    }else{
        header('location:register.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">

    <!-- my style css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- fivicon -->
    <link rel = "icon" type = "image/jpg" href = "assets/images/icons/Spotify_Green.png">

    <!-- google font -->
    <link href="https://fonts.googleapis.com/css?family=Nunito|PT+Sans&display=swap" rel="stylesheet"> 

    <title>Spotify - Home</title>
</head>
<body>

    <div id="mainContainer">

        <!-- main content -->
        <div id="topContainer">

            <!-- navigation bar -->
            <div id="navBarContainer">
                <nav class="navBar">
                    <!-- Spotify logo -->
                    <a href="index.php" class="logo">
                        <img src="assets/images/logo/Spotify_Logo_White.png" alt="spotify">
                    </a>
                    
                    <!-- navigation Items -->
                    <!-- Search bar -->
                    <div class="group">
                        <div class="navItem">
                            <a href="search.php" class="navItemLink search">
                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve" width="30px" height="30px">
                                <g><g>
                                    <g>
                                        <path d="M508.875,493.792L353.089,338.005c32.358-35.927,52.245-83.296,52.245-135.339C405.333,90.917,314.417,0,202.667,0    S0,90.917,0,202.667s90.917,202.667,202.667,202.667c52.043,0,99.411-19.887,135.339-52.245l155.786,155.786    c2.083,2.083,4.813,3.125,7.542,3.125c2.729,0,5.458-1.042,7.542-3.125C513.042,504.708,513.042,497.958,508.875,493.792z     M202.667,384c-99.979,0-181.333-81.344-181.333-181.333S102.688,21.333,202.667,21.333S384,102.677,384,202.667    S302.646,384,202.667,384z"/>
                                    </g>
                                    </g></g>
                                </svg>
                                 Search
                            </a>
                        </div>
                    </div>

                    <!-- other items -->
                    <div class="group">
                        <div class="navItem">
                            <a href="browse.php" class="navItemLink">
                            <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	                        viewBox="0 0 415.963 415.963" style="enable-background:new 0 0 415.963 415.963;" width="30px" height="30px" xml:space="preserve">
                            <path d="M328.712,264.539c12.928-21.632,21.504-48.992,23.168-76.064c1.056-17.376-2.816-35.616-11.2-52.768
                            c-13.152-26.944-35.744-42.08-57.568-56.704c-16.288-10.912-31.68-21.216-42.56-35.936l-1.952-2.624
                            c-6.432-8.64-13.696-18.432-14.848-26.656c-1.152-8.32-8.704-14.24-16.96-13.76c-8.384,0.576-14.88,7.52-14.88,15.936v285.12
                            c-13.408-8.128-29.92-13.12-48-13.12c-44.096,0-80,28.704-80,64s35.904,64,80,64s80-28.704,80-64V165.467
                            c24.032,9.184,63.36,32.576,74.176,87.2c-2.016,2.976-3.936,6.176-6.176,8.736c-5.856,6.624-5.216,16.736,1.44,22.56
                            c6.592,5.888,16.704,5.184,22.56-1.44c4.288-4.864,8.096-10.56,11.744-16.512C328.04,265.563,328.393,265.083,328.712,264.539z"/>
                            <g>
                            </g>
                            </svg>
                                 Browse
                            </a>
                        </div>
                        <div class="navItem">
                            <a href="yourMusic.php" class="navItemLink">
                            <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 489.7 489.7" style="enable-background:new 0 0 489.7 489.7;" xml:space="preserve">
                            <g>
                                <g>
                                    <path d="M52.7,134.75c29.1,0,52.7-23.7,52.7-52.7s-23.6-52.8-52.7-52.8S0,52.95,0,81.95S23.7,134.75,52.7,134.75z M52.7,53.75
                                        c15.6,0,28.2,12.7,28.2,28.2s-12.7,28.2-28.2,28.2s-28.2-12.7-28.2-28.2S37.2,53.75,52.7,53.75z"/>
                                    <path d="M52.7,297.55c29.1,0,52.7-23.7,52.7-52.7s-23.6-52.7-52.7-52.7S0,215.75,0,244.85S23.7,297.55,52.7,297.55z M52.7,216.65
                                        c15.6,0,28.2,12.7,28.2,28.2s-12.7,28.2-28.2,28.2s-28.2-12.6-28.2-28.2S37.2,216.65,52.7,216.65z"/>
                                    <path d="M52.7,460.45c29.1,0,52.7-23.7,52.7-52.7c0-29.1-23.7-52.7-52.7-52.7S0,378.75,0,407.75C0,436.75,23.7,460.45,52.7,460.45
                                        z M52.7,379.45c15.6,0,28.2,12.7,28.2,28.2c0,15.6-12.7,28.2-28.2,28.2s-28.2-12.7-28.2-28.2C24.5,392.15,37.2,379.45,52.7,379.45
                                        z"/>
                                    <path d="M175.9,94.25h301.5c6.8,0,12.3-5.5,12.3-12.3s-5.5-12.3-12.3-12.3H175.9c-6.8,0-12.3,5.5-12.3,12.3
                                        S169.1,94.25,175.9,94.25z"/>
                                    <path d="M175.9,257.15h301.5c6.8,0,12.3-5.5,12.3-12.3s-5.5-12.3-12.3-12.3H175.9c-6.8,0-12.3,5.5-12.3,12.3
                                        S169.1,257.15,175.9,257.15z"/>
                                    <path d="M175.9,419.95h301.5c6.8,0,12.3-5.5,12.3-12.3s-5.5-12.3-12.3-12.3H175.9c-6.8,0-12.3,5.5-12.3,12.3
                                        S169.1,419.95,175.9,419.95z"/>
                                </g>
                            </g></svg>
                                Your music
                            </a>
                        </div>
                        <div class="navItem">
                            <a href="profile.php" class="navItemLink">
                            <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 483.5 483.5" style="enable-background:new 0 0 483.5 483.5;" xml:space="preserve">
                                <g>
                                    <g>
                                        <path d="M430.75,471.2v-67.8c0-83.9-55-155.2-130.7-179.8c36.4-20.5,61.1-59.5,61.1-104.2c0-65.8-53.6-119.4-119.4-119.4
                                            s-119.4,53.6-119.4,119.4c0,44.7,24.7,83.7,61.1,104.2c-75.8,24.6-130.7,95.9-130.7,179.8v67.8c0,6.8,5.5,12.3,12.3,12.3h353.6
                                            C425.25,483.4,430.75,478,430.75,471.2z M146.75,119.4c0-52.3,42.6-94.9,94.9-94.9s94.9,42.6,94.9,94.9s-42.6,94.9-94.9,94.9
                                            S146.75,171.7,146.75,119.4z M406.25,458.9H77.05v-55.6c0-90.7,73.8-164.6,164.6-164.6s164.6,73.8,164.6,164.6V458.9z"/>
                                    </g>
                                </g>
                            </svg>
                         Kacee Piper</a>
                        </div>
                        <div class="navItem logout">
                            <a href="logout.php" class="navItemLink">
                            <svg height="30pt" viewBox="1 0 511 512" width="30pt" xmlns="http://www.w3.org/2000/svg"><path d="m135.738281 361.070312c7.140625 8.425782 6.097657 21.046876-2.328125 28.1875-8.4375 7.148438-21.058594 6.085938-28.1875-2.328124l-100.007812-118c-6.378906-7.523438-6.191406-18.558594 0-25.859376l100.007812-118c7.140625-8.429687 19.761719-9.46875 28.1875-2.328124 8.425782 7.140624 9.46875 19.761718 2.328125 28.1875l-72.097656 85.070312h355.042969c11.046875 0 20.003906 8.953125 20.003906 20s-8.957031 20-20.003906 20h-355.042969zm356.761719-361.070312h-173.820312c-11.046876 0-20 8.953125-20 20s8.953124 20 20 20h153.816406v432h-153.816406c-11.046876 0-20 8.953125-20 20s8.953124 20 20 20h173.820312c11.042969 0 20-8.953125 20-20v-472c0-11.046875-8.957031-20-20-20zm0 0"/></svg>
                            <span id="log">Logout</span>
                            </a>
                        </div>
                    </div>
                </nav>
            </div>

            <!-- Music container -->
            <div class="musicContainer">
                <center><h1>Welcome to Spotify</h1></center>
            </div>
        </div>

        <!-- Play bar at the footer -->
        <div id="nowPlayingBarContainer">
            <div id="nowPlayingBar">

                <!-- current playing music -->
                <div id="nowPlayingLeft">
                    <div class="content">
                        <span class="albumLink">
                            <img src="assets/images/songImg/square.jpg" alt="" class="albumArtwork">
                        </span>

                        <div class="trackInfo">
                            <span class="trackName">
                                <span>Imaginary</span>
                            </span>
                            <span class="artistName">
                                <span>Imran Khan</span>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- music controls -->
                <div id="nowPlayingCenter">
                    <div class="content playerControls">
                        <div class="buttons">
                            <button class="controlButton shuffle" title="Enable Shuffle">
                                <img src="assets/images/icons/shuffle.png" alt="Shuffle">
                            </button>

                            <button class="controlButton previous" title="Previous">
                                <img src="assets/images/icons/previous.png" alt="Previous">
                            </button>

                            <button class="controlButton play" title="Play">
                                <img src="assets/images/icons/play.png" alt="Play">
                            </button>

                            <button class="controlButton pause" title="Pause" style="display:none;">
                                <img src="assets/images/icons/pause.png" alt="Pause">
                            </button>

                            <button class="controlButton next" title="Next">
                                <img src="assets/images/icons/next.png" alt="Next">
                            </button>

                            <button class="controlButton repeat" title="Enable Repeat">
                                <img src="assets/images/icons/repeat.png" alt="Repeat">
                            </button>
                        </div>

                        <!-- Progress bar -->
                        <div class="playbackBar">
                            <span class="progressTime current">
                                0:00
                            </span>

                            <div class="progressBar">
                                <div class="progressBarBg">
                                    <div id="progress"></div>
                                </div>
                            </div>

                            <span class="progressTime remaining">
                                0:00
                            </span>
                        </div>

                    </div>
                </div>

                <!-- voice control -->
                <div id="nowPlayingRight">
                    <div class="volumeBar">
                        <button class="controlButton volume" title="volume">
                            <img src="assets/images/icons/volume.png" alt="volume">
                        </button>
                        <div class="progressBar volume">
                            <div class="progressBarBg">
                                <div id="progress"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>