<?php
    include('includes/config.php');
    include('includes/classes/Constants.php');
    include('includes/classes/Account.php'); 
    $account = new Account($con);
    include('includes/handlers/login_handler.php');
    include('includes/handlers/register_handler.php');
    function getInputValue($name){
        if(isset($_POST[$name])){
            echo $_POST[$name];
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">

    <!-- my css for register.php -->
    <link rel="stylesheet" href="assets/css/register.css">
    
    <!-- favicon -->
    <link rel = "icon" type = "image/jpg" href = "assets/images/icons/Spotify_White.png">

    <!-- Jquery link -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- my JavaScript -->
    <script src="assets/js/register.js"></script>

    <!-- google font -->

    <title>Sign up - Spotify</title>
</head>
<body>

    <!-- Script for relevent form -->
    <?php 
        if(isset($_POST['SignUp'])){
            echo ' <script>
                        $(document).ready(function(){
                            $("#loginForm").hide();
                            $("#registerForm").show();
                        });
                    </script>';
        }
        else{
            echo ' <script>
                        $(document).ready(function(){
                            $("#loginForm").show();
                            $("#registerForm").hide();
                        });
                    </script>';
        }
    ?>
    <!-- background image -->
    <div id="background">
        <div class="header">
            <div class="col-md-12 col-lg-12 img-fluid">
                <a href="index.php"><img src="assets/images/logo/Spotify_Logo_White.png" alt="" width="200"></a>
            </div>
        </div>
        <div id="loginContainer">
            <!-- main contents start here -->
                <div id="inputContainer">
                    <form action="register.php" method="POST" id="loginForm">
                        <h2>Login to your account</h2>
                        <!-- username -->
                        <p>
                            <label for="username">Username</label>
                            <input type="text" name="username" id="loginUsername" placeholder="Username" value="<?php getInputValue('username');?>" required>
                        </p>
                        <!-- Password -->
                        <p id="loginPassword">
                            <?php echo $account->getError(Constrants::$loginFailed);?>
                            <label for="password">Password</label>
                            <input type="password" name="password" id="password" placeholder="Password" required>
                        </p>
                        <!-- login:submit -->
                        <button type="submit" name="Login">Log In</button>

                        <div class="hasAccountText">
                            <span id="hideLogin">Don't have an account yet? Signup here.</span>
                        </div>
                    </form>
                    <form action="register.php" method="POST" id="registerForm">
                        <h2>Create your free account</h2>
                        <p>
                            <?php echo $account->getError(Constrants::$usernameLength);?>
                            <?php echo $account->getError(Constrants::$userNameTaken);?>
                            <label for="username">Username</label>
                            <input type="text" name="username" id="username" placeholder="Username" value="<?php getInputValue('username');?>" required>
                        </p>
                        
                        <!-- first name -->
                        <p>
                            <?php echo $account->getError(Constrants::$fnLength);?>
                            <label for="firstname">First Name</label>
                            <input type="text" name="firstname" id="firstname" placeholder="First name" value="<?php getInputValue('firstname');?>" required>
                        </p>

                        <!-- last name -->
                        <p>
                            <?php echo $account->getError(Constrants::$lnLength);?>
                            <label for="firstname">Last Name</label>
                            <input type="text" name="lastname" id="lastname" placeholder="Last name" value="<?php getInputValue('lastname');?>" required>
                        </p>

                        <!-- email -->
                        <p>
                            <?php echo $account->getError(Constrants::$emailNotMatch);?>
                            <?php echo $account->getError(Constrants::$emailInvalid);?>
                            <?php echo $account->getError(Constrants::$emailTaken);?>
                            <label for="firstname">Email</label>
                            <input type="email" name="email" id="email" placeholder="Email" value="<?php getInputValue('email');?>" required>
                        </p>

                        <!-- confirm email -->
                        <p>
                            <label for="ConfirmEmail">Confirm email</label>
                            <input type="email" name="confirmEmail" id="confirmEmail" placeholder="Confirm email" value="<?php getInputValue('confirmEmail');?>" required="required">
                        </p>

                        <!-- password -->
                        <p>
                            <?php echo $account->getError(Constrants::$pwDoNotMatch);?>
                            <?php echo $account->getError(Constrants::$pwNotAlphanumeric);?>
                            <?php echo $account->getError(Constrants::$pwLength);?>
                            <label for="">Password</label>
                            <input type="password" name="password" id="password" placeholder="Password" required="required">
                        </p>

                        <!-- confirm password -->
                        <p>
                            <label for="confirmPassoword">Confirm Password</label>
                            <input type="password" name="confirmPassword" id="confiemPassword" placeholder="Confirm password" required>
                        </p>

                        <!-- submit -->
                        <button type="submit" name="SignUp">Sign Up</button>

                        <div class="hasAccountText">
                            <span id="hideRegister">Already have an account? Log in here.</span>
                        </div>
                    </form>
                </div>

                <!-- Right side content -->
                <div class="loginText">
                    <h1>Get great music, right now.</h1>
                    <h2>Listen to loads of songs for free.</h2>
                    <ul>
                        <li>Discover music you'll fall in love with.</li>
                        <li>Create your own playlists.</li>
                        <li>Follow artists to keep up to date.</li>
                    </ul>
                </div>
        </div>
    </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>
<?php
    // echo "Clear error";
     // for deleting error message if you refresh the page
    
?>