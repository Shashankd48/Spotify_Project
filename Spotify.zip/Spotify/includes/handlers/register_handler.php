<?php
    function sanitizeFormUsername($intputText){
        $intputText = strip_tags($intputText);  //get rid of html tags 
        $intputText = str_replace(" ","",$intputText);  //replaces all the space
        return $intputText;
    }
    function sanitizeFormNames($intputText){
        $intputText = sanitizeFormUsername($intputText);
        $intputText =  ucfirst(strtolower($intputText));    //Uppercase 1st char,lower case rest of all
        return $intputText;
    }
    function sanitizeFormPossword($intputText){
        $intputText = strip_tags($intputText);
        return $intputText;
    }
    if(isset($_POST['SignUp'])){
        // Username
        $username = sanitizeFormUsername($_POST['username']);
        // firstname
        $firstname = sanitizeFormNames($_POST['firstname']);
        //lastname
        $lastname = sanitizeFormNames($_POST['lastname']);
        //Email
        $email = sanitizeFormUsername($_POST['email']);
        // confirm email
        $confirmEmail = sanitizeFormUsername($_POST['confirmEmail']);
        //Password
        $password = sanitizeFormPossword($_POST['password']);
        //Password;
        $confirmPassword = sanitizeFormPossword($_POST['confirmPassword']);
        
        //Validating from date
        $wasSuccessful =$account->register($username,$firstname,$lastname,$email,$confirmEmail,$password,$confirmPassword);
        if($wasSuccessful){
            $_SESSION['userLoggedIn'] = $username; 
            header('location:index.php');
        }
    }
?>