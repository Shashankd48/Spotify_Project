<?php
    include('includes/config.php');
    include('includes/classes/Constants.php');
    include('includes/classes/Account.php');
    $account = new Account($con);
    include('includes/handlers/login_handler.php');
    function getInputValue($name){
        if(isset($_POST[$name])){
            echo $_POST[$name];
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <!-- favicon -->
    <link rel = "icon" type = "image/jpg" href = "spotify.png">
    <title>Login - Spotify</title>
</head>
<body>
    <div class="container">
        <h1 class="mb-5 mt-2"><i class="fab fa-spotify"></i> Spotify</h1>
        <div id="inputContainer">
            <form action="login.php" method="POST" id="loginForm">
                <h2>Login to Your account</h2>
                <?php echo $account->getError(Constrants::$loginFailed);?>
                <p><input type="text" name="username" id="loginUsername" placeholder="Username" required></p>
                <p><input type="password" name="password" id="password" placeholder="Password" required></p>
                <p>
                    <button type="submit" class="btn btn-success" value="Login" name="Login">Login</button><span><a href="register.php" class="btn btn-primary ml-4">Sign Up</a></span>
                </p>
            </form>
        </div>
    </div>
    
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>