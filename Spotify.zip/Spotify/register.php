<?php
    include('includes/config.php');
    include('includes/classes/Constants.php');
    include('includes/classes/Account.php'); 
    $account = new Account($con);
    include('includes/handlers/register_handler.php');
    function getInputValue($name){
        if(isset($_POST[$name])){
            echo $_POST[$name];
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/register.css">
    <!-- favicon -->
    <link rel = "icon" type = "image/jpg" href = "spotify.png">
    <title>Sign up - Spotify</title>
</head>
<body>
    <!-- background image -->
    <div id="background">
        <div class="header">
            <div class="col-md-12 col-lg-12 img-fluid">
                <a href="index.php"><img src="assets/images/webPages/Spotify_Logo.png" alt="" width="200"></a>
            </div>
        </div>
        <div id="loginContainer">
            <!-- main contents start here -->
                <div id="inputContainer">
                    <form action="register.php" method="POST" id="loginForm">
                        <h2>Create your free account</h2>
                        <?php echo $account->getError(Constrants::$usernameLength);?>
                        <?php echo $account->getError(Constrants::$userNameTaken);?>
                        <p><input type="text" name="username" id="username" placeholder="Username" value="<?php getInputValue('username');?>" required></p>
                        
                        <!-- first name -->
                        <?php echo $account->getError(Constrants::$fnLength);?>
                        <p><input type="text" name="firstname" id="firstname" placeholder="First name" value="<?php getInputValue('firstname');?>" required></p>

                        <!-- last name -->
                        <?php echo $account->getError(Constrants::$lnLength);?>
                        <p><input type="text" name="lastname" id="lastname" placeholder="Last name" value="<?php getInputValue('lastname');?>" required></p>

                        <!-- email -->
                        <?php echo $account->getError(Constrants::$emailNotMatch);?>
                        <?php echo $account->getError(Constrants::$emailInvalid);?>
                        <?php echo $account->getError(Constrants::$emailTaken);?>
                        <p><input type="email" name="email" id="email" placeholder="Email" value="<?php getInputValue('email');?>" required></p>
                        <!-- confirm email -->
                        <p><input type="email" name="confirmEmail" id="confirmEmail" placeholder="Confirm email" value="<?php getInputValue('confirmEmail');?>" required="required"></p>

                        <!-- password -->
                        <?php echo $account->getError(Constrants::$pwDoNotMatch);?>
                        <?php echo $account->getError(Constrants::$pwNotAlphanumeric);?>
                        <?php echo $account->getError(Constrants::$pwLength);?>
                        <label for="">Password</label>
                        <p><input type="password" name="password" id="password" placeholder="Password" required></p>
                        <!-- confirm password -->
                        <p><input type="password" name="confirmPassword" id="confiemPassword" placeholder="Confirm password" required></p>
                        <!-- submit -->
                        <button type="submit" name="SignUp">Sign Up</button>
                    </form>
                </div>
        </div>
    </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>
<?php
    // echo "Clear error";
     // for deleting error message if you refresh the page
    
?>